/**
 * BIBLIOTECA VIRTUAL JOSEFA DIAS
 * Recebe as fichas de leitura do site e grava em uma planilha institucional.
 *
 * COMO CONFIGURAR:
 * 1. Abra https://script.google.com/ com a conta institucional da escola.
 * 2. Crie um novo projeto e substitua o conteúdo por este código.
 * 3. Execute a função CONFIGURAR pela primeira vez e autorize o acesso.
 * 4. Ela criará uma planilha chamada "Biblioteca Josefa Dias - Fichas de Leitura".
 * 5. Veja a URL da planilha no Registro de execução ou em CONFIGURAR().
 * 6. Implante: Implantar > Nova implantação > Aplicativo da Web.
 *    - Executar como: Eu
 *    - Quem tem acesso: Qualquer pessoa
 * 7. Copie a URL que termina em /exec.
 * 8. Cole essa URL em SCHOOL_ENDPOINT no HTML da biblioteca.
 */

const SHEET_NAME = 'Fichas de Leitura';
const SPREADSHEET_NAME = 'Biblioteca Josefa Dias - Fichas de Leitura';

function CONFIGURAR() {
  const props = PropertiesService.getScriptProperties();
  let id = props.getProperty('SPREADSHEET_ID');

  let ss;
  if (id) {
    ss = SpreadsheetApp.openById(id);
  } else {
    ss = SpreadsheetApp.create(SPREADSHEET_NAME);
    props.setProperty('SPREADSHEET_ID', ss.getId());
  }

  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);

  if (sheet.getLastRow() === 0) {
    sheet.appendRow([
      'Data/hora do envio',
      'Nome do aluno',
      'Turma',
      'Data da leitura',
      'Livro',
      'Autor',
      'Categoria',
      'Avaliação',
      'Resumo',
      'O que aprendeu',
      'Recomendaria?',
      'Link do livro',
      'Origem'
    ]);
    sheet.setFrozenRows(1);
    sheet.getRange(1,1,1,13).setFontWeight('bold');
    sheet.autoResizeColumns(1, 13);
  }

  Logger.log('PLANILHA: ' + ss.getUrl());
  return ss.getUrl();
}

function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({
      ok: true,
      message: 'Biblioteca Josefa Dias — endpoint ativo.'
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const props = PropertiesService.getScriptProperties();
    let id = props.getProperty('SPREADSHEET_ID');

    if (!id) {
      CONFIGURAR();
      id = props.getProperty('SPREADSHEET_ID');
    }

    const ss = SpreadsheetApp.openById(id);
    let sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet) {
      CONFIGURAR();
      sheet = ss.getSheetByName(SHEET_NAME);
    }

    const p = e.parameter || {};

    sheet.appendRow([
      new Date(),
      p.student || '',
      p.classroom || '',
      p.date || '',
      p.book || '',
      p.author || '',
      p.category || '',
      p.rating || '',
      p.summary || '',
      p.learning || '',
      p.recommend || '',
      p.bookUrl || '',
      p.source || 'Biblioteca Virtual Josefa Dias'
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    console.error(err);
    return ContentService
      .createTextOutput(JSON.stringify({
        ok:false,
        error:String(err)
      }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
